/*
This program simulates a very simple microprocessor model. The processor
has load, store, alu, fpu, and branch instructions. The probability of
a given instruction as well as its latency is coded in the program. It
should not be used for anything other than an introduction to the idea of
simulating a microprocessor; it is laughably inaccurate.
*/

#include <stdlib.h>
#include <iostream>
#include <assert.h>

// the different types of instructions

enum instruction_type {
	LOAD, STORE, ALU, FPU, BRANCH
};

// we'll simulate 10 million instructions.

#define NUMBER_OF_INSTRUCTIONS	10000000

// latencies of the different kinds of instructions
// latency is an expression of how much time it takes for a data packet to travel from one designated point to another
#define LOAD_LATENCY	10
#define STORE_LATENCY	5
#define ALU_LATENCY	1
#define FPU_LATENCY	3
#define BRANCH_LATENCY	2

// instruction mix

#define LOAD_PROBABILITY	0.30
#define STORE_PROBABILITY	0.15
#define ALU_PROBABILITY		0.30
#define FPU_PROBABILITY		0.05
#define BRANCH_PROBABIITY	0.20

// get a randomly generated instruction

instruction_type get_random_instruction (void) {
	// get a random number in [0,1]

	double r = (rand () % RAND_MAX) / (double) RAND_MAX;
	
	// determine what kind of instruction this is
	
	instruction_type t;
	if (r < LOAD_PROBABILITY) t = LOAD;
	else if (r < LOAD_PROBABILITY+STORE_PROBABILITY) t = STORE;
	else if (r < LOAD_PROBABILITY+STORE_PROBABILITY+ALU_PROBABILITY) t = ALU;
	else if (r < LOAD_PROBABILITY+STORE_PROBABILITY+ALU_PROBABILITY+FPU_PROBABILITY) t = FPU;
	else t = BRANCH;
	return t;
}

// main simulator loop

int main () {
	int cycle_count = 0, instruction_count = 0;

	for (int i=0; i<NUMBER_OF_INSTRUCTIONS; i++) {
		instruction_type t = get_random_instruction ();
		int instruction_latency;
		switch (t) {
		case LOAD: instruction_latency = LOAD_LATENCY; break;
		case STORE: instruction_latency = STORE_LATENCY; break;
		case ALU: instruction_latency = ALU_LATENCY; break;
		case FPU: instruction_latency = FPU_LATENCY; break;
		case BRANCH: instruction_latency = BRANCH_LATENCY; break;
		default: assert (0);
		}
		cycle_count += instruction_latency;
		instruction_count++;
	}
	std::cout << "CPI = " << cycle_count / (double) instruction_count << "\n";
	return 0;
}

/*
CPI equation for this processor:
CPI = 10 * 0.30 + 5 * 0.15 + 1 * 0.30 + 3 * 0.05 + 2 * 0.20 = 4.60
*/
